This folder is not example of mshadow code.
It is example code introducing expression template, the trick behind mshadow.

See: https://github.com/tqchen/mshadow/wiki/Expression-Template
