mv nnet.cu	nnet.cpp
mv convnet.cu	convnet.cpp
make -f Makefile.openblas