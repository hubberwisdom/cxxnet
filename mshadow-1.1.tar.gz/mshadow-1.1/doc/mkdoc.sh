#!/bin/bash
cd ../mshadow
doxygen ../doc/Doxyfile
cd ../doc
